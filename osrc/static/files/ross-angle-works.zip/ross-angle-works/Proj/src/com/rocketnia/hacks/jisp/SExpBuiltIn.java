package com.rocketnia.hacks.jisp;


public abstract class SExpBuiltIn extends SExpFunction
{
}